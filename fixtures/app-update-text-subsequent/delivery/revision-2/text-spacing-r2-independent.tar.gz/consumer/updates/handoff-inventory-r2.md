# Independent handoff inventory - revision 2

This bundle starts before `text-spacing-example-2`. No subsequent-adoption result,
patch, generated gate logs or private maintainer material is supplied. Inspect
actual code and installed identities rather than assuming adoption from history.

## Required supplied inputs

| Attachment | Purpose |
| --- | --- |
| [Instructions](../AGENTS.md), [task prompt](../TASK.md), [existing adoption record](../README.md) | Consumer scope and pre-update decisions |
| [Revision-2 independent guide](text-spacing-example-2-r2.md) | Selected change and required verification |
| [Revision-2 migration reference](persistence-migration-r2.md) | App ownership and portable references |
| [Base manifest](base-artifacts.json), [model report](model-artifact.json) | Exact identities and modeled artifact delta |
| [Artifacts](../artifacts/) | All 19 base archives plus the next Preset candidate |
| [Baseline Preset](../artifacts/asyra-preset-0.5.8.tgz), [next Preset](../artifacts/asyra-preset-0.5.8-task4.0.tgz) | Baseline installation and authorized later selection |
| [Manifest](../package.json), [lockfile](../yarn.lock), [Yarn settings](../.yarnrc.yml) | Baseline dependency resolution and local caching |
| [App and permanent tests](../src/) | Actual intervening extensions and behavior |
| [Original](../test-data/current.json), [multiplier](../test-data/multiplier.json), [intervening](../test-data/locally-extended.json) documents | Immutable saved inputs |
| [Public source copies](sources/index.md) | Pinned canonical source evidence, readable offline |
| [File checksums](../HANDOFF-SHA256.json) | Integrity of supplied files, excluding the checksum file itself |

All existing build, TypeScript, lint and test configuration is included. Node 24.x
and Yarn 4.3.1 are prerequisites; unrelated dependency installation uses the
existing lockfile and may require network access. `node_modules` and package
caches are not supplied. Do not substitute registry packages for local candidates.
Missing required files or identity mismatches block dependent integration.

## Optional history and provenance

The [original guide](text-spacing-example-2-r1.md),
[original migration reference](persistence-migration.md) and
[candidate builder](../tools/prepare-artifacts.py) are supplied unchanged.
Installing the provided target does not require running the builder. Never use
its output directory as its source directory. Original migration links into the
broader docs tree are historical only; use revision 2 for current navigation.

The pre-existing README mentions `VERIFICATION.md`, `evidence/`,
`updates/target-artifacts.json` and `test-results/text-adoption/`. These historical
attachments are not supplied or reconstructed. The existing record is context,
not fresh verification. No prior subsequent-adoption logs are included: generate
this run's own evidence under `test-results/subsequent-adoption/`.

Artifacts are Git-ignored but explicitly included in this bundle. A source-only
Git copy is insufficient. Do not inspect a parent checkout, earlier conversations
or unprovided maintainer evidence to fill gaps; report any required missing input.
