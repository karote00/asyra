# Independent subsequent Text update

Start with the [revision-2 independent handoff guide](text-spacing-example-2-r2.md),
[attachment inventory](handoff-inventory-r2.md) and [task prompt](../TASK.md).
This consumer is before the selected update. Adoption is pending.

The [original revision-1 guide](text-spacing-example-2-r1.md) and
[original migration attachment](persistence-migration.md) are unchanged history.
Use the [portable migration reference](persistence-migration-r2.md) for active links.
