# Modeled adoption note before intervening customization

This is scenario input, not an independent acceptance report.

| Scenario | Actual adopted baseline | Remaining work |
| --- | --- | --- |
| Direct legacy documents | No completed modeled stage; document version 1 | Inspect all three App records and the Framework prerequisite. |
| Partial adoption | `model-text-app-1`, guide revision 1, partially adopted | Official renderer/base are in use; local line-height/spacing overrides were retained pending comparison. `model-text-app-2` and `model-text-app-3` remain deferred; documents are version 2. |

The selected installed candidates are Core 0.5.7 and Preset 0.5.8-task4.0, with
the Utils 0.5.2 local resolution. Exact archives are recorded in `artifacts.json`.
`model-text-framework` bytes are installed, but the App retains its old spacing
default. This is partial adoption, not completed integration.

Retain approvalStatus/sourceRecordId/labelCategory, approve/reject, chart captions
and their source links, and the shared gray text-color override. The official
Text panel remains deferred. No later edits are described by this older note;
inspect current code and samples before updating it. The user now selects the
official spacing default and App wire version 3 for this isolated exercise.

Append the new adoption result below. Keep this input note intact, and distinguish
actual checks from unverified assumptions and pending product choices.
