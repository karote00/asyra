# Cross-version Text consumer

This is a new, pre-integration modeled consumer. It does not contain a prior
independent acceptance result. Read `ADOPTION.md`, then begin at
`docs/public/updates/index.md` in the supplied delivery and follow the modeled
three-stage Text guide and release records. In the maintainer checkout the same
public documents live at the repository's `docs/public` path.

The installed package target is already newer than the App's adoption. The App
still has local line-height/spacing definitions and a version-2 save format.
Since the last adoption note the user added `reviewNote` and `annotate`; inspect
the code and preserve them. Core owns canonical state, Features own actions, the
App owns projection and serialization. The optional official Text panel remains
deferred; the existing custom approval button stays available.

`test-data/multiplier.json` is a direct version-1 input. `current.json` and
`locally-extended.json` are partial version-2 inputs. Preserve those files.
`ambiguous-units.json` deliberately needs a product decision and must remain
recoverable and rejected by the completed integration.

Use the declared Node 24 and Yarn 4.3.1. All dependencies already appear in the
manifest/lockfile. Keep installation state and logs inside this consumer:

```bash
mkdir -p .yarn/global .yarn/tmp test-results
export YARN_GLOBAL_FOLDER="$PWD/.yarn/global"
export TMPDIR="$PWD/.yarn/tmp"
yarn install --immutable
yarn test:baseline
yarn test:acceptance
```

The four acceptance cases intentionally fail on the input consumer; preservation
cases, types, lint and build must pass before integration. After following the
public guide, both suites must pass without weakening assertions. Run `yarn test`,
`yarn typecheck`, `yarn lint` and `yarn build`, retaining commands, statuses and logs
under `test-results/cross-version`. Update `ADOPTION.md` with the actual result.

This delivery contains only consumer inputs, public documentation, pinned source
attachments and retained candidate archives. Historical maintainer evidence and
this task's solution are not supplied. Required APIs can be inspected in installed
public package exports and `sources/`; no parent repository is needed. Historical
provenance links in public docs are not permission to inspect a parent checkout.
No package is to be published and no production storage may be changed.
