# `@asyra/ai-agent-runtime`

Optional orchestration for turning natural-language intent into registered,
app-approved actions.

## Owns

- provider request, small control-envelope validation, and ordered action
  resolution
- immutable common tool contracts and host-supplied validation middleware
- permission and optional confirmation sequencing
- one app transaction-runner invocation around accepted executors
- bounded redaction, progress observation, audit, terminal results, and cleanup

## Does not own

Model vendors, credentials, app-domain actions, Feature sessions, canonical
state, transaction implementation, collaboration, or provider retry after
execution begins.

## Compose when

Compose it when an app wants model-assisted intent behind explicit action
schemas, permission, and canonical app APIs. Do not compose it for ordinary
deterministic commands or as a substitute for Feature System. Import and
construction are inert until the app creates and runs a runtime.

## Public entrypoints and prerequisites

The public entrypoint is `@asyra/ai-agent-runtime`. Provide an `AiProvider`,
context provider, `AiActionDefinition` catalog, permission policy, confirmation
handler, transaction runner, and Feature-owned `AbortSignal`. Important
surfaces include `createAiAgentRuntime(...)`, `createAiActionRegistry()`,
`runtime.run(...)`, and `createGenericHttpAiProvider(...)`.
Each action also declares revision, output schema, effect, resources and lifecycle.
`createAiToolMiddleware()` enforces host schemas through `createAiInvoker()`;
registration alone is a declaration. Recording uses `createRecordDeliveryHost()`
with host-owned durable outbox storage. Diagnostic recovery never replays actions.

## Lifecycle, inputs, outputs, and failure

One run obtains bounded context, requests one provider-prepared batch, resolves
registered actions, evaluates permission, optionally confirms, and executes in
one app transaction. Results are `executed`, `cancelled`, or `failed` with
bounded detached evidence. Invalid batches, denial, cancellation, or abort
apply no canonical prefix. Executor failure reaches the app transaction's
rollback. `dispose()` aborts active work and disposes only explicitly owned
resources.

Scoped authored action progress has paired start/end notifications. Each actual
execution has an opaque invocation identity, distinct from batch-local action IDs;
causal trace children use that execution identity and retain original actionId and
batchId for correlation. Completion ends activity, not necessarily successful work.
Abort suppresses further observer notifications; consumers use the returned
cancelled outcome to settle their UI. Progress never authorizes mutation or retry.

When actions need revision-bound receipt capture, the App mutation executor
honors `runAiMutation(context, mutate, settled?)`: call `settled(result)` once,
synchronously after successful canonical publication and before yielding. Keep
capture failure separate from the completed mutation; never replay a write to
recover its receipt.

### Diagnostic storage and retry ownership

Diagnostic outbox adapters implement atomic `append(records)` for an ordered, single-request batch partitioned at `recordStorageBatchBytes` (256 KiB), with an individual record still subject to capture and transport bounds. The delivery sink keeps its existing pending-byte bound and streams durable prefixes independently from later storage work. A failed atomic append records the entire enclosing lost range; it never synthesizes completion or replays product operations.

File-backed collectors retain only a recent digest window. Older retries are checked against the durable stream using a bounded sequential cursor; restart streams the evidence without retaining all hashes. Explicit host record budgets still apply. A generic collector without durable retry lookup retains its bounded in-memory admission budget.

## Relationships

Feature System owns the invocation session. App executors call Core/common APIs.
Factory owns actual transaction settlement. Collaboration and Persistence
observe ordinary canonical commits; the AI runtime creates no parallel path.

## Maintained use path

Follow [Build registered AI actions](../../build/ai-actions.md). The related
[app retrieval guide](../../build/app-retrieval-action.md) keeps search
read-only and mutation behind a Feature API.

## Replacement and disabled behavior

`AiProvider` is replaceable. Apps may replace context, permission,
confirmation, transaction, audit, and HTTP adapters. If the package is not
composed, no provider request, model connection, credential read, or AI state
exists. A provider failure must not fall back to an unregistered action.

## Support, migration, and deprecation

Current support is the browser composition with app-owned provider/backend
policy. There is no current Headless Core service runtime. The root API is
current; no compatibility wrapper or alternate client payload mode is
supported. Migration must preserve action schemas, prepared argument identity,
permission defaults, and one-transaction behavior.

## Canonical sources and release inventory

- [Package contract](../../../ai/framework/packages/ai-agent-runtime.md)
- [Package manifest](../../../../packages/ai-agent-runtime/package.json)
- [Registered AI action guide](../../build/ai-actions.md)

Version and exported-entry facts are generated from this package manifest into
`docs/public/generated/package-reference.json`. The documentation gate reviews
this page against the exact 19-package release inventory.
