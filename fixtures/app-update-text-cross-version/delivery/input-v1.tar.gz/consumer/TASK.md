# Isolated cross-version consumer acceptance

Work only inside this extracted `consumer` directory. Read `AGENTS.md`, README,
the existing adoption note and the supplied public update entry. Follow the
modeled cross-version Text guide to integrate the selected stages while preserving
the App's current custom fields, Features, visible projections and saved data.
Use the exact supplied candidate artifacts. This is an explicitly authorized
modeled exercise, not a real registry upgrade or deployment.

Verify `HANDOFF-SHA256.json` and `artifacts.json` before edits. Run the existing
baseline gates, confirm the target acceptance cases fail for the expected missing
behavior, then perform integration and run the final tests, types, lint and build.
Add permanent tests where the guide requires a case not already covered; do not
remove or weaken existing preservation assertions. Record actual adoption and
remaining choices in the adoption note, and retain logs with exit statuses under
`test-results/cross-version`.

You have no prior discussion context. Do not read parent repositories, other chats,
maintainer plans/evidence, or another implementation. Public docs and installed
candidate APIs are the integration authority. Use no subagents. Keep all writes,
caches and temporary files inside this consumer. No Git metadata is included;
initialize a local repository here before any Git command so parent Git state is
never used. Do not install new dependencies or tools, change candidate archives,
edit immutable samples, publish, deploy, push or create a PR.
