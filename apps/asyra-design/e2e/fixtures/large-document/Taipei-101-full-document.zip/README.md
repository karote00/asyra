# Taipei 101 - full editable document backup

Captured from the user-owned `my-design` document at localhost:3000 on 2026-10-06.
The checkpoint and durable backend record agreed at sequence 586, generation 0; two HTTP reads had identical SHA-256.
No source document was reset, edited, reloaded, or replaced by this capture.

## Files

- `bootstrap-checkpoint.json`: exact response bytes from the read-only bootstrap endpoint.
- `backend-record.json`: exact durable store record, including persistence metadata.
- `document.json` (inside the ZIP): native AppDocumentData (`version`, `sceneTree`, `props`), extracted losslessly from the checkpoint.
- `manifest.json`: source revision, capture metadata, sizes and hashes.
- `document-summary.json`: offline counts and reference checks.

All geometry, element/property IDs, shared references, fills, hierarchy and names are preserved. This is an editable data backup, not a raster image or simplified export. No external/embedded image references were found in this document. AI conversation history and the user's camera/selection are not document contents and are not claimed as backed up.

## Safe recovery and performance replay

Keep this original backup immutable. Verify hashes before use. Restore through the application's canonical document load/bootstrap contract into a NEW isolated document ID with independent backend/collaboration storage, then compare the resulting canonical document and counts. Do not point performance tests or Reset at `my-design`; do not copy the old sequence/id envelope over another active backend. The backend record is disaster-recovery evidence, not a browser-import format. No restore into the live user document was attempted.
